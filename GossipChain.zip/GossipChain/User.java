import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;
public class User
{
	private final UUID id;
	private final String legalName;
	private String displayName;
	private int grade;
	private final LocalDateTime createdAt;

	private User(UUID id, String legalName, String displayName, int grade, LocalDateTime createdAt)
	{
		this.id = id;
		this.legalName = legalName;
		this.displayName = displayName;
		this.grade = grade;
		this.createdAt = createdAt;
	}
	public static User newUser(String legalName, String displayName, int grade)
	{
		requireGrade(grade);
		Objects.requireNonNull(legalName);
		Objects.requireNonNull(displayName);
		return new User(UUID.randomUUID(), legalName, displayName, grade, LocalDateTime.now());
	}
	public void rename(String displayName)
	{
		this.displayName = Objects.requireNonNull(displayName);
	}
	public void changeGrade(int grade)
	{
		requireGrade(grade);
		this.grade = grade;
	}
	public static void requireGrade(int grade)
	{
		if(grade < 1 || grade > 12)
		{
			throw new IllegalArgumentException("Grade must be 1 - 12");
		}
	}
	public UUID getId()
	{
		return this.id;
	}
	public String getLegalName()
	{
		return this.legalName;
	}
	public String getDisplayName()
	{
		return this.displayName;
	}
	public int getGrade()
	{
		return this.grade;
	}
	public LocalDateTime getDate()
	{
		return this.createdAt;
	}
	@Override
	public boolean equals(Object o)
	{
		if(this == o)
		{
			return true;
		}
		if(o instanceof User user && id.equals(user.id))
		{
			return true;
		}
		return false;
	}
	@Override
	public int hashCode()
	{
		return this.id.hashCode();
	}
}