import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

public final class RelationshipEdge
{
    private final UUID fromID;
    private final UUID toID;
    private final RelationshipType type;
    private RelationshipStatus status;
    private final LocalDateTime requestedAt;
    private LocalDateTime updatedAt;

    private RelationshipEdge(UUID fromID, UUID toID, RelationshipType type, RelationshipStatus status, LocalDateTime requestedAt)
    {
        this.fromID = Objects.requireNonNull(fromID);
        this.toID = Objects.requireNonNull(toID);
        this.type = Objects.requireNonNull(type);
        this.status = Objects.requireNonNull(status);
        this.requestedAt = requestedAt;
        this.updatedAt = requestedAt;
    }
    public static RelationshipEdge createRequest(UUID fromID, UUID toID, RelationshipType type)
	{
        if(fromID.equals(toID))
        {
            throw new IllegalArgumentException("Cannot relate to self");
        }
		return new RelationshipEdge(fromID, toID, type, RelationshipStatus.PENDING, LocalDateTime.now());
	}
    public void accept()
    {
        transitionTo(RelationshipStatus.ACTIVE);
    }
    public void reject()
    {
        transitionTo(RelationshipStatus.REJECTED);
    }
    public void block()
    {
        transitionTo(RelationshipStatus.BLOCKED);
    }
    public void cancel()
    {
        transitionTo(RelationshipStatus.CANCELLED);
    }
    private void transitionTo(RelationshipStatus status)
    {
        if(this.status == RelationshipStatus.ACTIVE && status == RelationshipStatus.REJECTED)
        {
            throw new IllegalStateException("Cannot reject active relationship");
        }
        this.status = status;
        updatedAt = LocalDateTime.now();
    }
    
    public UUID getFromID()
    {
        return fromID;
    }
    public UUID getToID()
    {
        return toID;
    }
    public RelationshipType getType()
    {
        return type;
    }
    public RelationshipStatus getStatus()
    {
        return status;
    }
    public LocalDateTime getTimeRequested()
    {
        return requestedAt;
    }
    public LocalDateTime getTimeUpdated()
    {
        return updatedAt;
    }
    @Override
    public boolean equals(Object o)
    {
        if(this == o)
        {
            return true;
        }
        if(!(o instanceof RelationshipEdge e))
        {
            return false;
        }
        if(fromID.equals(e.fromID) && toID.equals(e.toID) && type.equals(e.type))
        {
            return true;
        }
        return false;
    }
    @Override
    public int hashCode()
    {
        return Objects.hash(fromID, toID, type);
    }
    @Override
    public String toString()
    {
        return "Edge[" + fromID + "-" + toID + "-" + type + "-" + status + "]";
    }

}

