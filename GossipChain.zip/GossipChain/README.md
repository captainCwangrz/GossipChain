User
		- id (UUID)
		- legalName 
		- displayName
		- grade
		- createdAt
	RelationshipType
		- enum
		- DATING, BFF, BEEFING
	RelationshipStatus
		- PENDING, ACTIVE, BLOCKED, REJECTED
	RelationshipEdge
		- fromID
		- toID
		- type
		- sta
    