public enum RelationshipStatus
{
    PENDING,
    ACTIVE,
    BLOCKED,
    REJECTED,
    CANCELLED
}

