public enum RelationshipType
{
    DATING(true),
    BEST_FRIEND(true),
    BROTHER(true),
    SISTER(true),
    BEEFING(true),
    CRUSH(false);

    private final boolean symetric;

    RelationshipType(boolean symetric)
    {
        this.symetric = symetric;
    }

    public boolean isSymetric()
    {
        return symetric;
    }
}